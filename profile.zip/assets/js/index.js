var typing = new Typed('#typed', {
    strings: [
        'Fullstack Developer.',
        'Eat, Sleep and Code.',
        'Good Boy.'
    ],
    typeSpeed: 80,
    backSpeed: 40,
    backDelay: 8000,
    loop: true,
});

var typingDesc = new Typed('#desc', {
    strings: [
        'console.log("My name Duong Van Hiep.");'
    ],
    typeSpeed: 40,
    backSpeed: 30,
    showCursor: false,
    loop: false,
});